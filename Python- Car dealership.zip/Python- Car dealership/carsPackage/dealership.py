#prints a file 
def options(d):
    print('\n  make model year price\n---------------------------')
    for key,value in d.items():
        print('{}-{}'.format(key,'-'.join(value)))

#finds an item within dictionary d and adds to cart if found
def find(x,d,cart):
    for key,value in d.items():
        if x == key:
            #value = d[key]
            cart[x] = d[x]
            return cart
    return False

#prints items in cart
def display_car(cart):
    #prints the items in cart
    print("\nYour wishlist:")
    for key,value in cart.items():
        print('{}-{}'.format(key,'-'.join(value)))
        

